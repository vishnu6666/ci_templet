<!DOCTYPE html>
<html>
<head>
	<title>welcome to codeigniter </title>

	<link href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet" type="text/css"/>
	
</head>
<body>
	<div class="wrapper">
            <?php 
                
                $this->load->view('include/header');
            ?>
                {content}
            <?php
           
                $this->load->view('include/footer');
            ?>
        </div>

    <script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

</body>
</html>