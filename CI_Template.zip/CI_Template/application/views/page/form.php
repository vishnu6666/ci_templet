
  <div>
  	<p>welcome to codeigniter with form</p>
  </div>
	<div class="container">
	<form action="Cform/insert_data" method="POST" multipart>
	  <div class="form-group row">
	    <label for="name" class="col-sm-2 col-form-label">Name</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="name" name="name" placeholder="Name">
	    </div>
	  </div>
	  <div class="form-group row">
	    <label for="mobile" class="col-sm-2 col-form-label">Mobile</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile">
	    </div>
	  </div>
	  <fieldset class="form-group">
	    <div class="row">
	      <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
	      <div class="col-sm-10">
	        <input type="radio" name="gender" value="Male">Male
	        <input type="radio" name="gender" value="Female">Female  
	      </div>
	    </div>
	  </fieldset>
	  <div class="form-group row">
	    <div class="col-sm-2">Education</div>
	    <div class="col-sm-10">
	      <div class="btn-group">
  			<select name="education" type="select" multiple="">
  				<option>Select option</option>
  				<option value="BE">BE</option>
  				<option value="Btech">Btech</option>
  				<option value="ME">ME</option>
  			</select>
	    </div>
	  </div>
	  <div class="form-group row">
	    <div class="col-sm-10">
	      <button type="submit" class="btn btn-primary">Submit</button>
	    </div>
	  </div>
	</div>
	</form>
	</div>

 		

