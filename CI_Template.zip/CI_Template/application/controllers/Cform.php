<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cform extends CI_Controller {

	public function index()
	{
		$CI =& get_instance();

		$data = array(
	    				'title' => "Form"
	    	         );
		$content = $CI->parser->parse('page/form',$data ,true);
		
		$this->template->full_html_view($content);
	}
	public function insert_data()
	{
		$name = $this->input->post('name');
		$mobile = $this->input->post('mobile');
		$gender = $this->input->post('gender');
		$education = $this->input->post('education');
		$data = array(
				'name'=>$name,
				'mobile'=>$mobile,
				'gender'=>$gender,
				'education'=>$education,
				);
		echo "<pre>";
		print_r($data);
		exit;
	}
}