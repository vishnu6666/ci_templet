<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends CI_Controller {

	function __construct()
	{
		parent:: __construct();

	}
	public function index()
	{
		$CI =& get_instance();
		$data = array(
						'title' => 'Home'
					);
		$content = $CI->parser->parse('include/admin_home',$data,true);
		
		$this->template->full_admin_html($content);
	}
}
